ShootToMiss
=================

Purpose
----

Every shot taken will have a random chance of hitting its target or completely missing. A very simple plugin that you can use to expand on if you want to.

Use
----

Set the `s2m_chance` config value either in the System menu or via command. The default value is set to 0.25. This means that shots will have a 25% chance to it, the value ranges between 0 and 1.